class MobileCallbackHandler {
  constructor(callbackFunction) {
    this.utils = new Utils();
    this.callback = callbackFunction;
  }

  init() {
    this.addInteractionClickEvents();
    this.addModalAndGlossaryLinksFunctionality();
    this.addFeedbackStarsFunctionality();
  }

  removeOnClickEvent(element) {
    element.removeAttribute('onclick')
  }

  addInteractionClickEvents() {
    const that = this;
    const callback = this.callback;
    const elements = this.utils.getDOMElements('[data-dialogonclick-value]');
    elements.map((element) => {
      this.removeOnClickEvent(element);
      element.addEventListener(
        'click',
        function (e) {
          const action = element.getAttribute('data-dialogonclick-value');
          switch (action) {
            case 'end': // fallthough
            case 'cancel':
              const feedbackModal = that.utils.getDOMElement('.modal--feedback')
              if (feedbackModal) {
                const feedbackValue = that.utils.getDOMElement('.modal--feedback').getAttribute('data-feedback-value');
                if (feedbackValue) {
                  // get data-feedback-value (prop) from .modal--feedback
                  const score = feedbackValue * 20;
                  const message = { dialog_response: 'end', FEEDBACK_SCORE: score.toString() };
                  return callback(message);
                }
              }

              console.warn('End interaction without feedback !');
              return callback({
                dialog_response: action
              });

            default:
              callback({
                dialog_response: action
              });
              break;
          }
        },
        {
          once: !0
        }
      );
    });
  }

  // modal functionality - feedback stars
  addFeedbackStarsFunctionality() {
    const that = this;
    // find all DOM modal triggers - stars
    const modalTriggers = this.utils.getDOMElements('.feedback--star__label');
    // find modal target
    const modal = this.utils.getDOMElement('.modal--feedback');

    modalTriggers.map((star, i) => {
      // add modal trigger event
      star.addEventListener('click', (e) => {
        modal.classList.toggle('is--visible');
        // set feedback value as property on feedback modal
        modal.setAttribute('data-feedback-value', star.previousElementSibling.value);
      });
    });
  }

  // handle display of modal popup
  showModal(modal) {
    // mark item on action-list as completed after showing the modal
    const modalButton = document.querySelectorAll('.popup-modal__finished');
    modalButton.forEach((modalButtonItem, i) => {
      modalButtonItem.addEventListener('click', () => {
        let checklistItem = document.querySelector(`.list--checklist__item--${i}`);
        let checklistInput = checklistItem.querySelector('.input--checklist__input');

        checklistItem.classList.add('finished');
        checklistInput.checked = true;
      });
    });

    const modalInput = modal.querySelector('.modal-input');
    if (modalInput) {
      modalInput.addEventListener('focus', function() {
        window.scrollTo(0, 0);
        document.body.scrollTop = 0;
      });
      setTimeout(() => {
        modalInput.focus();
      }, 100);
    }
  }

  // glossary modals functionality
  addModalAndGlossaryLinksFunctionality() {
    const that = this;

    // find all DOM modal triggers
    const modalTriggers = this.utils.getDOMElements('.popup-trigger, a');

    modalTriggers.map((trigger, i) => {

      // create attribute from part of the local anchor href
      if (!trigger.hasAttribute("data-popup-trigger")) {
        const triggerHrefValue = trigger.getAttribute('href');

        // do not add modal event if anchor href does not contain #
        if (triggerHrefValue.indexOf('#') == '-1') {
          return null;
        }

        trigger.setAttribute('data-popup-trigger', triggerHrefValue.replace('#', ''));
      }

      // find modal target - modal: prop data-popup-modal = trigger: prop data-popup-trigger
      const modal = this.utils.getDOMElement(
        `[data-popup-modal='${trigger.getAttribute('data-popup-trigger')}']`
      );

      // add modal trigger event
      trigger.addEventListener('click', (e) => {
        e.preventDefault();
        modal.classList.add('is--visible');
        that.showModal(modal);
      });

      // find modal close button
      const modalCloseTrigger = this.utils.getDOMElement('.popup-modal__close', modal);
      // add close button functionality
      modalCloseTrigger.addEventListener('click', () => {
        modal.classList.remove('is--visible');
      });
    });
  }
}

class MobileCallbackHandler {
  constructor(callbackFunction) {
    this.utils = new Utils();
    this.callback = callbackFunction;
  }

  init() {
    this.addInteractionClickEvents();
    this.addGlossaryLinksFunctionality();
    this.addFeedbackStarsFunctionality();
  }

  addInteractionClickEvents() {
    const that = this;
    const callback = this.callback;
    const elements = this.utils.getDOMElements('[data-dialogonclick-value]');
    elements.map((element) => {
      element.addEventListener(
        'click',
        function (e) {
          const action = element.getAttribute('data-dialogonclick-value');
          switch (action) {
            case 'end': // fallthough
            case 'cancel':
              const feedbackValue = that.utils
                .getDOMElement('.modal--feedback')
                .getAttribute('data-feedback-value');
              if (!feedbackValue) {
                console.warn('End interaction without feedback !');
                return callback({
                  dialog_response: action
                });
              }

              // get data-feedback-value (prop) from .modal--feedback
              const score = feedbackValue * 20;
              const message = { dialog_response: 'end', FEEDBACK_SCORE: score.toString() };
              return callback(message);

            default:
              callback({
                dialog_response: action
              });
              break;
          }
        },
        {
          once: !0
        }
      );
    });
  }

  // modal functionality - feedback stars
  addFeedbackStarsFunctionality() {
    const that = this;
    // find all DOM modal triggers - stars
    const modalTriggers = this.utils.getDOMElements('.feedback--star__label');
    // find modal target
    const modal = this.utils.getDOMElement('.modal--feedback');

    modalTriggers.map((star, i) => {
      // add modal trigger event
      star.addEventListener('click', (e) => {
        modal.classList.toggle('is--visible');
        // set feedback value as property on feedback modal
        modal.setAttribute('data-feedback-value', star.previousElementSibling.value);
      });
    });
  }

  // glossary modals functionality
  addGlossaryLinksFunctionality() {
    // find all DOM modal triggers
    const modalTriggers = this.utils.getDOMElements('a');

    modalTriggers.map((trigger, i) => {
      const triggerHrefValue = trigger.getAttribute('href');

      // do not add modal event if anchor href does not contain #
      if (triggerHrefValue.indexOf('#') == '-1') {
        return null;
      }

      trigger.setAttribute('data-popup-trigger', triggerHrefValue.replace('#', ''));

      // find modal target - modal: prop data-popup-modal = trigger: prop data-popup-trigger
      const modal = this.utils.getDOMElement(
        `[data-popup-modal='${trigger.getAttribute('data-popup-trigger')}']`
      );

      // add modal trigger event
      trigger.addEventListener('click', (e) => {
        e.preventDefault();
        modal.classList.toggle('is--visible');
      });

      // find modal close button
      const modalCloseTrigger = this.utils.getDOMElement('.popup-modal__close', modal);
      // add close button functionality
      modalCloseTrigger.addEventListener('click', () => {
        modal.classList.remove('is--visible');
      });
    });
  }
}

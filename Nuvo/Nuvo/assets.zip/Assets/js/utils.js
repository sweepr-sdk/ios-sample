class Utils {
  // returns element matching selector present in container
  // container = parent element - default = document
  getDOMElement(selector, container = document) {
    return container.querySelector(selector);
  };

  // returns array of elements matching selector present in container
  // container = parent element - default = document
  getDOMElements(selector, container = document) {
    return Array.from(document.querySelectorAll(selector));
  };

  setElementContent(element, content) {
    element.innerHTML = content;
  };

  // add/remove style from element
  // property = element style (display/color/etc)
  // value = element style value (block/red/etc)
  toggleElementStyle(element, property, value = 'initial') {
    element.style[property] = value;
  };

  // prepares and returns the url to make requests
  // localhost uses mocked API
  getAPIDomain(host, prefix) {
    if (/localhost/g.test(host)) return `http://localhost:3000`;
    let h = host.split('.');
    h.splice(0, 1);
    h = h.join('.');
    return `https://${prefix}.${h}`;
  };

  // returns a wrapped request containing necessary header information
  requestWrapper(url, method = 'GET', data) {
    const host = window.location.host;
    return new Promise((resolve, reject) => {
      fetch(`${this.getAPIDomain(host, 'api')}${url}`, {
        method: method,
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        },
        body: data && JSON.stringify(data)
      })
        .then((response) => {
          response.ok && resolve(response.json());
          // handle errors - to be added
        })
        .catch((error) => {
          // it will be invoked mostly for network errors
          console.warn('request error :', error);
          reject({ error: error.message });
          reject(error);
        });
    });
  };
}

const modalTriggers = document.querySelectorAll('.popup-trigger');
const modalCloseTrigger = document.querySelectorAll('.popup-modal__close');
const stepBody = document.querySelector('body')

const modalButton = document.querySelectorAll('.popup-modal__finished');
const modalInput = document.querySelector('.modal-input');
const modalInterval = 400;


if(modalTriggers){
  //Find and loop each button/trigger for a modal
  modalTriggers.forEach(function (trigger, i) {

      //Set the data-attribute for modals
      let popupModals = document.querySelectorAll('.popup-modal');

      //Loop each modal and set data attribute to equal that of its trigger
      popupModals.forEach(function (popupModal, i) {
          popupModal.setAttribute("data-popup-modal", `${i}`);
      });

      //When clicked show modal and add class to body
      trigger.addEventListener('click', () => {
          // const { popupTrigger } = trigger.dataset

          const popupModal = document.querySelector(`[data-popup-modal="${i}"]`);
          stepBody.classList.add('modal-active');

          popupModal.classList.add('is--visible');

          modalCloseTrigger.forEach((modalCloseTriggerItem) => {
              modalCloseTriggerItem.addEventListener('click', () => {
                  stepBody.classList.remove('modal-active');
                  popupModal.classList.remove('is--visible')
              })
          })


          //Add finished class to corresponding checklist item and increase width of progress element
          modalButton.forEach((modalButtonItem, i) => {
              modalButtonItem.addEventListener('click', () => {
                  let checklistItem = document.querySelector(`.list--checklist__item--${i}`),
                      checklistInput = checklistItem.querySelector('.input--checklist__input');

                  checklistItem.classList.add('finished');

                  if (checklistInput.checked == false) {
                      checklistInput.checked = true;
                      width += checklistProgressInterval;
                      checklistProgressBar.style.transform = `scaleX(${width})`;
                  }
              })
          })

          if (modalInput) {
             setTimeout(() => {
                 modalInput.focus()
             }, modalInterval);
          }
      })
  })
}

if(modalInput){
  modalInput.addEventListener('focus', function(){
    window.scrollTo(0, 0);
      document.body.scrollTop = 0;
  })
}
